g++ apriori.cpp -o apriori -O3
g++ fptree.cpp -o fptree -O3
g++ graph_apriori.cpp -o graph_apriori -O3
g++ graph_fptree.cpp -o graph_fptree -O3

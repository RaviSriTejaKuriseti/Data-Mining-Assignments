Explanation of Files:

Team Members:

1)KURISETI RAVI SRI TEJA - 2019CS10369
2)APPAKONDA ABHIJITH REDDY - 2019CS10330
3)BOMMAKANTI VENKATA NAGA SAI ADITYA - 2019CS50471

Contribution: All three of us worked on all parts equally
Contribution Percentage:
1)Ravi : 33
2)Abhijith : 33
3)Aditya : 33

Models used:
Task 1: SAGEConv
Task 2: A3TGCN

Only train nodes were used to compute loss and backpropogate
